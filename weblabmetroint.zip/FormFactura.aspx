﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="FormFactura.aspx.cs" Inherits="LabMetro.FormFactura" MasterPageFile="~/mp.Master" MaintainScrollPositionOnPostback="true" %>

<asp:Content ID="Content2" runat="server" ContentPlaceHolderID="headerContent">

    <script type="text/javascript">

        var allCheckBoxSelector = '#<%=dgOrigem.ClientID%> input[id*="chkAll"]:checkbox';
        var checkBoxSelector = '#<%=dgOrigem.ClientID%> input[id*="dgOrigem"]:checkbox';

        function ToggleCheckUncheckAllOptionAsNeeded() {
            var totalCheckboxes = $(checkBoxSelector),
         checkedCheckboxes = totalCheckboxes.filter(":checked"),
         noCheckboxesAreChecked = (checkedCheckboxes.length === 0),
         allCheckboxesAreChecked = (totalCheckboxes.length === checkedCheckboxes.length);

            $(allCheckBoxSelector).attr('checked', allCheckboxesAreChecked);
        }

        $(document).ready(function() {
            $(allCheckBoxSelector).live('click', function() {
                $(checkBoxSelector).attr('checked', $(this).is(':checked'));

                ToggleCheckUncheckAllOptionAsNeeded();
            });

            $(checkBoxSelector).live('click', ToggleCheckUncheckAllOptionAsNeeded);

            ToggleCheckUncheckAllOptionAsNeeded();
        });

    </script>

</asp:Content>
<asp:Content ID="Content3" runat="server" ContentPlaceHolderID="scriptContent">

    <script type="text/javascript" language="javascript">
        function CheckKey() {
            if (event.keyCode == 13) {
                document.getElementById("btnSubmit").focus();
            }
        }
    </script>

</asp:Content>
<asp:Content ID="Content1" runat="server" ContentPlaceHolderID="mainContent">
    <fieldset>
        <legend>
            <%=Resources.Resource.Factura %></legend>
        <fieldset>
            <legend>
                <%=Resources.Resource.Empresa %></legend>
            <asp:Label ID="lblMessage" runat="server" ForeColor="red"></asp:Label><asp:ValidationSummary ID="valSummary"
                runat="server" HeaderText="Preencha por favor os seguintes campos:" ShowSummary="True"
                CssClass="lblMessage" DisplayMode="List" Font-Bold="True"></asp:ValidationSummary>
            <table>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.Empresa %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtPesquisaEmpresa" runat="server" AutoPostBack="true"></asp:TextBox>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.NIF %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtPesquisaNif" runat="server" AutoPostBack="true"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.CodClienteSAP %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtPesquisaNumClienteSAP" runat="server" AutoPostBack="true"></asp:TextBox>
                    </td>
                    <td colspan="2">
                        <asp:Button class="button" ID="btnEmpresas" CssClass="button" runat="server" Text="<%$ Resources:Resource, PesquisarEmpresa %>"
                            CausesValidation="false"></asp:Button>
                    </td>
                </tr>
                <tr id="trEmpresa" runat="server">
                    <td>
                        <label>
                            <%=Resources.Resource.EmpresaBRE %>:</label>
                    </td>
                    <td colspan="3">
                        <asp:DropDownList ID="ddEmpresa" runat="server" AutoPostBack="true" DataTextField="nome"
                            DataValueField="idEmpresa">
                        </asp:DropDownList>
                        <asp:Label ID="lblEmpresa" runat="server"></asp:Label><asp:RequiredFieldValidator
                            ID="Requiredfieldvalidator1" runat="server" ControlToValidate="ddEmpresa" ErrorMessage="Empresa">*</asp:RequiredFieldValidator>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.Localidade %>
                            <%=Resources.Resource.EmpresaBRE %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtLocalidade" runat="server" AutoPostBack="true" Width="224px"></asp:TextBox>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.RegiaoVendas %>
                            <%=Resources.Resource.EmpresaBRE %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddRegiaoVendasEmpresa" runat="server">
                        </asp:DropDownList>
                        <br />
                         <asp:RequiredFieldValidator
                        ID="RequiredFieldValidator6" runat="server" ControlToValidate="ddRegiaoVendasEmpresa">*</asp:RequiredFieldValidator>

                        <asp:Button class="button" ID="btnUpdateRegiaoVendasEmpresa" CssClass="button" runat="server"
                            Text="Actualizar Região" CausesValidation="false"></asp:Button>
                    </td>
                </tr>
                <tr id="trEmpresaContratante" runat="server">
                    <td>
                        <label>
                            <%=Resources.Resource.BRE %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddBRE" runat="server" AutoPostBack="true" DataTextField="refBRE"
                            DataValueField="idBRE">
                        </asp:DropDownList>
                        <asp:Label ID="lblBRE" runat="server"></asp:Label>&nbsp;&nbsp;&nbsp;<asp:CheckBox
                            ID="cbBRE" runat="server" AutoPostBack="True" Text="&nbsp;&nbsp;<%$ Resources:Resource, SoBRECompletos %>"
                            Checked="True"></asp:CheckBox>
                    </td>
                    <td colspan="2">
                        <label>
                            <%=Resources.Resource.FacturarA %>:</label><asp:DropDownList ID="ddEmpresaContratante"
                                runat="server" DataTextField="nomeEmpresaContratante" DataValueField="idEmpresaContratante">
                            </asp:DropDownList>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            Orçamento (ANG):</label>
                    </td>
                    <td>
                        <asp:HyperLink ID="linkOrcamento" runat="server" Target="_blank"></asp:HyperLink>
                    </td>
                    <td>
                        <label>
                            Ref. Req. BRE (ANG):</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtRefReq" runat="server" Enabled="false"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.BSE %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddbSE" runat="server" AutoPostBack="true" DataTextField="refBSE" DataValueField="idBSE">
                        </asp:DropDownList>
                    </td>
                    <td>
                    </td>
                    <td>
                    </td>
                </tr>
            </table>
            <table>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.BloqSistemaCentral %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddCodigoBloqueioSAP" runat="server" Enabled="False">
                        </asp:DropDownList>
                        &nbsp;
                    </td>
                    <td colspan="2">
                        <asp:Label ID="lblEmpresaDevedora" runat="server" CssClass="lblMessage"></asp:Label>&nbsp;
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.NumClienteSAP %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtNumClienteSAP" runat="server" AutoPostBack="true" Width="224px"
                            Enabled="False"></asp:TextBox>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.CondicoesPagamentoEmpresa %>:</label>
                    </td>
                    <td <%if(ddCondPagamentoEmpresa.SelectedValue=="1") Response.Write("bgcolor = red");%>>
                        <asp:DropDownList ID="ddCondPagamentoEmpresa" runat="server" Enabled="False">
                        </asp:DropDownList>
                        &nbsp;
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <label>
                            <%=Resources.Resource.NaoPrecisaReqFacturar %>:</label>
                        <asp:CheckBox ID="cbNPrecisaReqPFacturar" runat="server" Enabled="False"></asp:CheckBox>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.ObservacoesEmpresa %>:</label>
                    </td>
                    <td colspan="3">
                        <asp:Label ID="lblObsEmpresa" runat="server"></asp:Label>
                    </td>
                </tr>
                <tr><td colspan="4"><span style="font-weight:bold">Obs.BRE:</span><asp:TextBox ID="txtObsBRE" runat="server" Enabled="false" Font-Bold="true" Font-Size="Larger" Width="600" BorderColor="Red"></asp:TextBox></td></tr>
                <tr><td colspan="4"><span style="font-weight:bold">Obs.BSE:</span><asp:TextBox ID="txtObsBSE" runat="server" Enabled="false" Font-Bold="true" Font-Size="Larger" Width="600" BorderColor="Red"></asp:TextBox></td></tr>
            </table>
        </fieldset>
        <fieldset>
            <legend>
                <%=Resources.Resource.Requisicoes %></legend>
            <asp:Button class="button" ID="btnRequisicoes" runat="server" Text="<%$ Resources:Resource, VerRequisicoes %>"
                CausesValidation="true"></asp:Button>
            <asp:DataGrid ID="dgRequisicoes" runat="server" DataKeyField="idRequisicao" OnPageIndexChanged="DoPaging"
                OnSortCommand="SortGrid" AllowSorting="True" PageSize="10" AllowPaging="true"
                AutoGenerateColumns="false">
                <Columns>
                    <asp:BoundColumn DataField="referenciaCliente" SortExpression="referenciaCliente"
                        HeaderText="<%$ Resources:Resource, RefReqCliente %>"></asp:BoundColumn>
                    <asp:TemplateColumn HeaderText="<%$Resources:Resource, EmpresaTemContrato %>" SortExpression="eContrato">
                        <ItemTemplate>
                            <%# ConverteEstado(Convert.ToBoolean(DataBinder.Eval(Container, "DataItem.eContrato"))) %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:BoundColumn DataField="dtRequisicao" SortExpression="dtRequisicao" HeaderText="<%$ Resources:Resource, DtReq %>"
                        DataFormatString="{0:dd/MM/yyyy}" ItemStyle-Wrap="False"></asp:BoundColumn>
                    <asp:BoundColumn DataField="dtValidade" SortExpression="dtValidade" HeaderText="<%$ Resources:Resource, DtVal %>"
                        DataFormatString="{0:dd/MM/yyyy}" ItemStyle-Wrap="False"></asp:BoundColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, Completa %>" SortExpression="completa">
                        <ItemTemplate>
                            <%# ConverteEstado(Convert.ToBoolean(DataBinder.Eval(Container, "DataItem.completa"))) %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, Renovavel %>" SortExpression="bRenovavel">
                        <ItemTemplate>
                            <%# ConverteEstado(Convert.ToBoolean(DataBinder.Eval(Container, "DataItem.bRenovavel"))) %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, Ficheiro %>" SortExpression="nomeFicheiro">
                        <ItemTemplate>
                            <asp:HyperLink runat="server" NavigateUrl='<%#downloadpath(DataBinder.Eval(Container,"DataItem.nomeFicheiro"))%>'
                                ID="Hyperlink1" Target="new">
														<%# DataBinder.Eval(Container.DataItem, "nomeFicheiro")%>
                            </asp:HyperLink>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:HyperLinkColumn HeaderText="<%$ Resources:Resource, EditarRequisicao %>" DataNavigateUrlFormatString="FormRequisicao.aspx?btn=Doc&id={0}"
                        DataNavigateUrlField="idRequisicao" Target="_new" DataTextField="refRequisicao"
                        SortExpression="refRequisicao">
                        <ItemStyle HorizontalAlign="center"></ItemStyle>
                    </asp:HyperLinkColumn>
                    <asp:HyperLinkColumn HeaderText="<%$ Resources:Resource, VerServicos %>" DataNavigateUrlFormatString="ListaServicosRequisicao.aspx?btn=Doc&id={0}"
                        DataNavigateUrlField="idRequisicao" Target="_new" Text="<%$ Resources:Resource, Ver %>">
                        <ItemStyle HorizontalAlign="center"></ItemStyle>
                    </asp:HyperLinkColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, MarcarCompleta %>">
                        <ItemTemplate>
                            <asp:CheckBox runat="server" ID="chbCompleta" AutoPostBack="True" Checked='<%#DataBinder.Eval(Container.DataItem, "completa") %>'
                                OnCheckedChanged="cb_SetComplete"></asp:CheckBox>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                </Columns>
            </asp:DataGrid>
        </fieldset>
        <fieldset>
            <legend>
                <%= Resources.Resource.ServicosAFacturar %></legend>
            <asp:Label ID="lblEquipamentos" runat="server"></asp:Label>
            <asp:DataGrid ID="dgOrigem" runat="server" DataKeyField="idServico" OnSortCommand="SortGridOrigem"
                AllowSorting="true" AutoGenerateColumns="false" ShowFooter="false" OnEditCommand="editGridOrigem"
                OnCancelCommand="cancelGridOrigem" OnUpdateCommand="updateGridOrigem" OnItemDataBound="dgOrigem_ItemDataBound">
                <Columns>
                    <asp:TemplateColumn>
                        <HeaderTemplate>
                            (Des)marcar todos<asp:CheckBox runat="server" ID="chkAll" />
                            <%--<asp:CheckBox runat="server" ID="headerSelectCheckbox" ClientIDMode="Static" /> --%>
                        </HeaderTemplate>
                        <ItemTemplate>
                            <asp:CheckBox runat="server" ID="checkbox"></asp:CheckBox>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, RefCalib %>" SortExpression="refServico">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.refServico") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, NossaRefReq %>">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.refRequisicao") %>
                        </ItemTemplate>
                        <EditItemTemplate>
                            <asp:DropDownList ID="ddRequisicaoEdit" runat="server" DataValueField="idRequisicao"
                                DataTextField="referenciaCliente">
                            </asp:DropDownList>
                        </EditItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, RefReqCliente %>" SortExpression="referenciaCliente">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.referenciaCliente") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, NumIdent %>" SortExpression="numIdentificacao">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.numIdentificacao") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, TipoEquipamento %>" SortExpression="tipoEquipamento">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.tipoEquipamento") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, Estado %>" SortExpression="estadoServico">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.estadoServico") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, DtEstado %>" SortExpression="dtEstado">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.dtEstado") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, TipoServico %>" SortExpression="tipoServico">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.tipoServico") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, Obs %>" SortExpression="observacoes">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.observacoes") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, CalibExt %>" SortExpression="calibracaoExterna">
                        <ItemTemplate>
                            <%# ConverteEstado(Convert.ToBoolean(DataBinder.Eval(Container, "DataItem.calibracaoExterna"))) %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:EditCommandColumn EditText="Editar" UpdateText="Alterar" CancelText="Cancelar"
                        ItemStyle-Width="100"></asp:EditCommandColumn>
                </Columns>
            </asp:DataGrid>
            <asp:Button class="button" ID="btnSubmitGrid" runat="server" Text="<%$ Resources:Resource, FacturarEquipamentos %>"
                CausesValidation="true"></asp:Button>
            <br />
        </fieldset>
        <fieldset>
            <legend>
                <%=Resources.Resource.DadosFactura %></legend>
            <table>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.NumFactura %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtRefFactura" runat="server" ReadOnly="True"></asp:TextBox>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.DataFactura %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtDtFactura" runat="server" ReadOnly="False"></asp:TextBox>
                        <asp:CompareValidator
                            ID="Comparevalidator5" runat="server" ControlToValidate="txtDtFactura"
                            ErrorMessage="dd-mm-aaaa" Operator="DataTypeCheck"
                            Type="Date">*</asp:CompareValidator>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.ForcarData %>:</label>
                    </td>
                    <td>
                        <asp:CheckBox ID="cbForcarData" runat="server"></asp:CheckBox>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.DataAssumida %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtDataFacturaForcada" runat="server"></asp:TextBox><asp:CompareValidator
                            ID="Comparevalidator6" runat="server" ControlToValidate="txtDataFacturaForcada"
                            ErrorMessage="dd-mm-aaaa" Operator="DataTypeCheck"
                            Type="Date">Formato errado</asp:CompareValidator>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.TipoDoc %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddTipoDocumento" runat="server">
                        </asp:DropDownList>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.CanalDistribuicao %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddCanalDistribuicao" runat="server">
                            <asp:ListItem Value="RE" Selected="True" Text="<%$ Resources:Resource, Retalho %>"></asp:ListItem>
                        </asp:DropDownList>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.EscritorioVendas %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddEscritorioVendas" runat="server">
                        </asp:DropDownList>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.CondicoesPagamento %>:</label>
                    </td>
                    <td>
                        <asp:DropDownList ID="ddCondPagamentoFactura" runat="server">
                        </asp:DropDownList>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.NomeFicheiro %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtFicheiro" runat="server" ReadOnly="True"></asp:TextBox>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.Versao %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtVersao" runat="server" ReadOnly="True"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.Observacoes %>:</label>
                    </td>
                    <td colspan="4">
                        <asp:TextBox ID="txtObservacoes" runat="server"></asp:TextBox>
                    </td>
                </tr>
                 <tr>
                    <td>
                        <label>
                           Ref. Pedido Cliente (Req./Ordem Compra etc):</label>
                    </td>
                    <td >
                        <asp:TextBox ID="txtRefPedidoCliente" runat="server" MaxLength="35"></asp:TextBox>
                    </td>
                     <td>
                        <label>
                           Data Pedido Cliente:</label>
                    </td>
                    <td colspan="4">
                        <asp:TextBox ID="txtDtPedidoCliente" runat="server"></asp:TextBox>
                    </td>
                </tr>
            </table>
            <asp:Label ID="lblErroRequisicoes" CssClass="lblMessage" runat="server"></asp:Label><br />
            <asp:DataGrid ID="dgDestino" runat="server" DataKeyField="idServico" OnSortCommand="SortGridDestino"
                AllowSorting="True" AutoGenerateColumns="false" ShowFooter="false" OnEditCommand="editGrid"
                OnCancelCommand="cancelGrid" OnUpdateCommand="updateGrid" OnItemDataBound="dgDestino_ItemDataBound">
                <Columns>
                    <asp:TemplateColumn>
                        <ItemTemplate>
                            <%# Container.ItemIndex+1 %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, IdServicoBD %>" SortExpression="idServico">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.idServico") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, Equipamento %>" SortExpression="codTipoEquipamento">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.tipoEquipamento") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, NumIdent %>" SortExpression="numIdentificacao">
                        <ItemTemplate>
                            <%# DataBinder.Eval(Container, "DataItem.numIdentificacao") %>
                        </ItemTemplate>
                    </asp:TemplateColumn>
                    <asp:HyperLinkColumn HeaderText="<%$ Resources:Resource, RefCalib %>" DataNavigateUrlFormatString="FormPastaEnsaio.aspx?id={0}"
                        DataNavigateUrlField="idServico" Target="_new" DataTextField="refServico" SortExpression="refServico">
                        <ItemStyle HorizontalAlign="center"></ItemStyle>
                    </asp:HyperLinkColumn>
                    <asp:BoundColumn DataField="referenciaCliente" SortExpression="referenciaCliente"
                        HeaderText="<%$ Resources:Resource, RefReqCliente %>" ReadOnly="True"></asp:BoundColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, Valor %>" SortExpression="valor"
                        ItemStyle-HorizontalAlign="Right">
                        <ItemTemplate>
                            <%# LabMetro.GERAL.clsGeral.ConvertDBMoneyToString(DataBinder.Eval(Container, "DataItem.valor"))%>
                        </ItemTemplate>
                        <EditItemTemplate>
                            <asp:TextBox ID="txtValorEdit" Text='<%# LabMetro.GERAL.clsGeral.ConvertDBMoneyToString(DataBinder.Eval(Container, "DataItem.valor")) %>'
                                runat="server" Width="80" />
                            <asp:CompareValidator ID="Comparevalidator2" runat="server" CssClass="errorMsg" Display="static"
                                ErrorMessage="!Formato" ControlToValidate="txtValorEdit" Type="Double" Operator="DataTypeCheck"></asp:CompareValidator>
                        </EditItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, DescontoEmPercentagem %>"
                        SortExpression="percDesconto" ItemStyle-HorizontalAlign="Right">
                        <ItemTemplate>
                            <%# LabMetro.GERAL.clsGeral.ConvertDBMoneyToString(DataBinder.Eval(Container, "DataItem.percDesconto"))%>
                        </ItemTemplate>
                        <EditItemTemplate>
                            <asp:TextBox ID="txtPercDescontoEdit" Text='<%#LabMetro.GERAL.clsGeral.ConvertDBMoneyToString(DataBinder.Eval(Container, "DataItem.percDesconto")) %>'
                                runat="server" Width="80" />
                            <asp:CompareValidator ID="Comparevalidator3" runat="server" CssClass="errorMsg" Display="static"
                                ErrorMessage="!Formato" ControlToValidate="txtPercDescontoEdit" Type="Double"
                                Operator="DataTypeCheck"></asp:CompareValidator>
                        </EditItemTemplate>
                    </asp:TemplateColumn>
                    <asp:TemplateColumn HeaderText="<%$ Resources:Resource, ValorFinal %>" SortExpression="valorFinal"
                        ItemStyle-HorizontalAlign="Right">
                        <ItemTemplate>
                            <%# LabMetro.GERAL.clsGeral.ConvertDBMoneyToString(DataBinder.Eval(Container, "DataItem.valorFinal"))%>
                        </ItemTemplate>
                        <EditItemTemplate>
                            <asp:TextBox ID="txtValorFinalEdit" Text='<%# LabMetro.GERAL.clsGeral.ConvertDBMoneyToString(DataBinder.Eval(Container, "DataItem.valorFinal")) %>'
                                runat="server" ReadOnly="True" Width="80" />
                        </EditItemTemplate>
                    </asp:TemplateColumn>
                    <asp:EditCommandColumn EditText="Editar" UpdateText="Alterar" CancelText="Cancelar"
                        ItemStyle-Width="100"></asp:EditCommandColumn>
                    <asp:ButtonColumn CommandName="Delete" Text="Remover"></asp:ButtonColumn>
                </Columns>
            </asp:DataGrid>
        </fieldset>
        <fieldset>
            <legend>
                <%=Resources.Resource.ValoresFactura %></legend>
            <table>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.AjudasCustoDeslocacoes %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtValorAjudasCustoDeslocacoes" runat="server" AutoPostBack="true"
                            Width="100px"></asp:TextBox><asp:CompareValidator ID="Comparevalidator1" runat="server"
                                CssClass="lblMessage" ControlToValidate="txtValorAjudasCustoDeslocacoes" Display="static"
                                ErrorMessage="!Formato" Operator="DataTypeCheck" Type="Double"></asp:CompareValidator>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.SubTotal %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtValorSubTotal" runat="server" Width="100px" ReadOnly="True"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>
                        <label>
                            <%=Resources.Resource.DespesasEnvio %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtValorDespesasEnvio" runat="server" AutoPostBack="true" Width="100px"></asp:TextBox><asp:CompareValidator
                            ID="Comparevalidator4" runat="server" CssClass="lblMessage" ControlToValidate="txtValorDespesasEnvio"
                            Display="static" ErrorMessage="!Formato" Operator="DataTypeCheck" Type="Double"></asp:CompareValidator>
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.DescontoTotal %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtDescontoTotal" runat="server" Width="100px" ReadOnly="True"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                    </td>
                    <td>
                        <label>
                            <%=Resources.Resource.Total %>:</label>
                    </td>
                    <td>
                        <asp:TextBox ID="txtValorTotalFactura" runat="server" Width="100px" ReadOnly="True"></asp:TextBox>
                    </td>
                </tr>
                <tr>
                    <td>
                    </td>
                    <td align="center">
                        <asp:Button class="button_confirm" ID="btnSubmit" runat="server" Text="<%$ Resources:Resource, Gravar %>"
                            CausesValidation="true"></asp:Button>
                    </td>
                    <td>
                    </td>
                    <td align="center">
                        <asp:Button class="button" ID="btnFicheiro" CssClass="button" runat="server" Text="<%$ Resources:Resource, GerarOrdemVenda %>"
                            CausesValidation="true" Width="150" Enabled="false"></asp:Button>
                        <br />
                        <asp:Button class="button" ID="btnVerFactura" CssClass="button" runat="server" Text="<%$ Resources:Resource, VerFactura %>"
                            Width="150" />
                        <br />
                        <asp:Button class="button" ID="btnReset" CssClass="button" runat="server" Text="<%$ Resources:Resource, NovaFactura %>"
                            CausesValidation="false" Width="150"></asp:Button>
                        <br />
                        <br />
                            <asp:Button class="button" ID="btn_WS" CssClass="button" runat="server" Text="Enviar para SAP "
                            CausesValidation="false" Width="150" OnClick="btn_WS_Click"></asp:Button>
                        <br />
                        <br />

                         <br />
                            <asp:Button class="button" ID="Button1" CssClass="button" runat="server" Text="SAP Facturação INTERNA "
                            CausesValidation="false" Width="150" OnClick="btn_WS_Interno_Click"></asp:Button>
                        <br />
                        <br />
                    </td>
                </tr>
            </table>
        </fieldset>
    </fieldset>
</asp:Content>
